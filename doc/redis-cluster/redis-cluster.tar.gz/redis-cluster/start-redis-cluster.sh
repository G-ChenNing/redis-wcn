/usr/local/redis-5.0.4/src/redis-server /usr/local/redis-cluster/5001/redis.conf
/usr/local/redis-5.0.4/src/redis-server /usr/local/redis-cluster/5002/redis.conf
/usr/local/redis-5.0.4/src/redis-server /usr/local/redis-cluster/5003/redis.conf
/usr/local/redis-5.0.4/src/redis-server /usr/local/redis-cluster/5004/redis.conf
/usr/local/redis-5.0.4/src/redis-server /usr/local/redis-cluster/5005/redis.conf
/usr/local/redis-5.0.4/src/redis-server /usr/local/redis-cluster/5006/redis.conf
