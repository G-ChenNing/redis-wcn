/usr/local/redis-5.0.4/src/redis-server /usr/local/redis-cluster/redis.conf
